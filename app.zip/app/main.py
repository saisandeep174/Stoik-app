from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from config import db
from routes import auth, doctors, appointments
import dev_routes
from datetime import datetime, timezone

app = FastAPI(title="Medical Appointment API", version="1.0.0")

# -------------------- CORS --------------------
origins = [
    "http://127.0.0.1:5500",
    "http://localhost:5500",
    "http://localhost:3000",
    "http://localhost:5173",  # Vite frontend URL
    "http://127.0.0.1:5173",
    "http://127.0.0.1:8000"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------- Routers --------------------
app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(doctors.router, prefix="/doctors", tags=["doctors"])
app.include_router(appointments.router, prefix="/appointments", tags=["appointments"])
app.include_router(dev_routes.router, tags=["dev"])

# -------------------- Startup Events --------------------
@app.on_event("startup")
async def init_indexes():
    await db.users.create_index("email", unique=True)
    await db.appointments.create_index(
        [("doctor_id", 1), ("appointment_time", 1)], unique=True
    )
    await db.doctors.create_index("specialization")

# -------------------- Health Check --------------------
@app.get("/health")
async def health():
    try:
        await db.command("ping")
        mongo = "ok"
    except Exception:
        mongo = "down"
    return {"status": "ok", "mongo": mongo}


@app.get("/")
async def root():
    return {"status": "ok"}