from fastapi import APIRouter, Depends, HTTPException
from typing import List
from models.appointment import AppointmentCreate, AppointmentPublic
from utils.auth import get_current_user
from config import db
from utils.helpers import parse_iso_datetime, objid
from datetime import datetime, timezone

router = APIRouter()

def to_utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    dt = dt.astimezone(timezone.utc)
    return dt.replace(second=0, microsecond=0)

@router.post("", response_model=AppointmentPublic, status_code=201)
async def book_appointment(payload: AppointmentCreate, user=Depends(get_current_user)):
    doctor = await db.doctors.find_one({"_id": objid(payload.doctor_id)})
    if not doctor:
        raise HTTPException(status_code=404, detail="Doctor not found")

    appt_dt = to_utc(parse_iso_datetime(payload.appointment_time))

    doctor_slots_dt = []
    for s in doctor.get("available_slots", []):
        dt = parse_iso_datetime(s) if isinstance(s, str) else s
        doctor_slots_dt.append(to_utc(dt))

    if not any(appt_dt == slot for slot in doctor_slots_dt):
        raise HTTPException(status_code=400, detail="Selected time is not in doctor's available slots")

    doc = {
        "user_id": str(user["_id"]),
        "doctor_id": str(doctor["_id"]),
        "appointment_time": appt_dt.isoformat().replace("+00:00", "Z"),
        "status": "Confirmed",
        "created_at": datetime.now(timezone.utc),
    }

    try:
        res = await db.appointments.insert_one(doc)
    except Exception as e:
        if "duplicate key" in str(e).lower():
            raise HTTPException(status_code=409, detail="Slot already booked")
        raise

    return AppointmentPublic(
        id=objid(res.inserted_id),
        user_id=doc["user_id"],
        doctor_id=doc["doctor_id"],
        doctor_name=doctor["name"],
        specialization=doctor["specialization"],
        appointment_time=doc["appointment_time"],
        status=doc["status"],
    )

@router.get("/me", response_model=List[AppointmentPublic])
async def my_appointments(user=Depends(get_current_user)):
    user_id_str = str(user["_id"])
    out: List[AppointmentPublic] = []

    pipeline = [
        {"$match": {"user_id": user_id_str}},
        {"$addFields": {"doctor_oid": {"$toObjectId": "$doctor_id"}}},
        {"$lookup": {
            "from": "doctors",
            "localField": "doctor_oid",
            "foreignField": "_id",
            "as": "doc"
        }},
        {"$unwind": "$doc"},
        {"$sort": {"appointment_time": 1}}
    ]

    async for ap in db.appointments.aggregate(pipeline):
        out.append(
            AppointmentPublic(
                id=str(ap["_id"]),
                user_id=ap["user_id"],
                doctor_id=ap["doctor_id"],
                doctor_name=ap["doc"]["name"],
                specialization=ap["doc"]["specialization"],
                appointment_time=ap["appointment_time"],
                status=ap.get("status", "Confirmed"),
            )
        )
    return out
