from fastapi import APIRouter, HTTPException, Header
from typing import List, Optional
from models.doctor import DoctorCreate, DoctorPublic
from utils.helpers import parse_iso_datetime, objid
from config import db, ADMIN_KEY
from datetime import datetime, timezone

router = APIRouter()

@router.get("", response_model=List[DoctorPublic])
async def list_doctors():
    docs = []
    async for d in db.doctors.find({}).sort("name", 1):
        docs.append(
            DoctorPublic(
                id=objid(d["_id"]),
                name=d["name"],
                specialization=d["specialization"],
                available_slots=[
                    (s if isinstance(s, str) else s.isoformat().replace("+00:00", "Z"))
                    for s in d.get("available_slots", [])
                ],
            )
        )
    return docs

@router.post("", response_model=DoctorPublic, status_code=201)
async def add_doctor(payload: DoctorCreate, x_admin_key: Optional[str] = Header(None)):
    if x_admin_key != ADMIN_KEY:
        raise HTTPException(status_code=401, detail="Admin key required")

    slots_dt = [parse_iso_datetime(s) for s in payload.available_slots]
    doc = {
        "name": payload.name,
        "specialization": payload.specialization,
        "available_slots": slots_dt,
        "created_at": datetime.now(timezone.utc),
    }
    res = await db.doctors.insert_one(doc)
    return DoctorPublic(
        id=objid(res.inserted_id),
        name=doc["name"],
        specialization=doc["specialization"],
        available_slots=[s.isoformat().replace("+00:00", "Z") for s in slots_dt],
    )

@router.get("/{doctor_id}/slots", response_model=List[str])
async def get_available_slots(doctor_id: str):
    d = await db.doctors.find_one({"_id": objid(doctor_id)})
    if not d:
        raise HTTPException(status_code=404, detail="Doctor not found")

    booked = set()
    async for ap in db.appointments.find({"doctor_id": doctor_id}):
        booked.add(ap["appointment_time"])

    iso_slots = [
        (s if isinstance(s, str) else s.isoformat().replace("+00:00", "Z"))
        for s in d.get("available_slots", [])
    ]
    remaining = [s for s in iso_slots if s not in booked]
    return sorted(remaining)
