from fastapi import APIRouter, HTTPException, status, Body, Depends
from fastapi.security import OAuth2PasswordRequestForm
from models.user import UserCreate, UserPublic, TokenResponse
from utils.auth import hash_password, verify_password, create_access_token
from config import db
from bson import ObjectId
from datetime import datetime, timezone, date
from google.oauth2 import id_token
from google.auth.transport import requests as google_requests
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from pymongo import MongoClient
from pydantic import BaseModel

from dotenv import load_dotenv

load_dotenv()

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

import os
SECRET_KEY = os.getenv("JWT_SECRET")
ALGORITHM = os.getenv("JWT_ALG", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("JWT_EXPIRE_MIN", 60))



if not SECRET_KEY:
    raise ValueError("JWT_SECRET must be set in .env or environment variables")

@router.post("/register", status_code=201)
async def register(payload: UserCreate):
    doc = payload.dict()
    password = doc.pop("password")
    
    # Convert date_of_birth to datetime for MongoDB
    dob = doc.get("date_of_birth")
    if isinstance(dob, date) and not isinstance(dob, datetime):
        doc["date_of_birth"] = datetime.combine(dob, datetime.min.time(), tzinfo=timezone.utc)

    doc["email"] = doc["email"].lower()
    doc["created_at"] = datetime.now(timezone.utc)
    doc["password_hash"] = hash_password(password)

    try:
        res = await db.users.insert_one(doc)
    except Exception as e:
        if "duplicate key" in str(e).lower():
            raise HTTPException(status_code=409, detail="Email already registered")
        raise

    return {"status": "success", "user_id": str(res.inserted_id)}


@router.post("/login", response_model=TokenResponse)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    email = form_data.username.lower()
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(form_data.password, user.get("password_hash", "")):
        raise HTTPException(status_code=400, detail="Incorrect email or password")

    user_public = UserPublic(id=str(user["_id"]), name=user["full_name"], email=user["email"])
    token = create_access_token({"sub": str(user["_id"])})
    return TokenResponse(token=token, user=user_public)

@router.post("/google-login")
async def google_login(payload: dict = Body(...)):
    token = payload.get("google_token")
    if not token:
        raise HTTPException(status_code=400, detail="Google token required")
    try:
        idinfo = id_token.verify_oauth2_token(token, google_requests.Request(), None)
        email = idinfo["email"].lower()
        name = idinfo.get("name", "No Name")
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid Google token")

    user = await db.users.find_one({"email": email})
    if not user:
        raise HTTPException(status_code=404, detail="User not found. Please register first.")

    jwt_token = create_access_token({"sub": str(user["_id"])})
    return {"status": "login", "token": jwt_token, "user": {"id": str(user["_id"]), "name": name, "email": email}}


class MeResponse(BaseModel):
    user: UserPublic

# Helper to get current user from JWT
async def get_current_user(token: str = Depends(oauth2_scheme)) -> UserPublic:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid token")
    except JWTError as e:
        print("JWT decoding error:", e)  # debug
        raise HTTPException(status_code=401, detail="Invalid token")

    user = await db.users.find_one({"_id": ObjectId(user_id)})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    print("Fetched user from DB:", user)  # debug
    return UserPublic(
        id=str(user["_id"]),
        name=user["full_name"],
        email=user["email"]
    )

# /auth/me endpoint
from fastapi import APIRouter, Depends
from .auth import get_current_user, UserPublic


@router.get("/me")
async def read_me(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid token")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

    user = await db.users.find_one({"_id": ObjectId(user_id)})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Convert ObjectId to str
    user["_id"] = str(user["_id"])
    # Convert date_of_birth & created_at to string for JSON serialization
    if "date_of_birth" in user and user["date_of_birth"]:
        user["date_of_birth"] = user["date_of_birth"].strftime("%Y-%m-%d")
    if "created_at" in user and user["created_at"]:
        user["created_at"] = user["created_at"].isoformat()

    return user
