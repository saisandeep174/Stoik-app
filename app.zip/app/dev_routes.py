from fastapi import APIRouter, Header, HTTPException
from config import db, ADMIN_KEY
from datetime import datetime, timezone

router = APIRouter()

@router.post("/dev/seed", tags=["dev"])
async def seed_doctors(x_admin_key: str = Header(None)):
    if x_admin_key != ADMIN_KEY:
        raise HTTPException(status_code=401, detail="Admin key required")

    await db.doctors.delete_many({})

    base_date = datetime(2025, 9, 2, tzinfo=timezone.utc)
    d1_slots = [base_date.replace(hour=h) for h in (9, 10, 11, 12)]
    d2_slots = [base_date.replace(hour=h) for h in (14, 15, 16)]

    docs = [
        {"name": "Dr. A Kumar", "specialization": "Cardiologist", "available_slots": d1_slots, "created_at": datetime.now(timezone.utc)},
        {"name": "Dr. B Reddy", "specialization": "Dermatologist", "available_slots": d2_slots, "created_at": datetime.now(timezone.utc)},
    ]

    result = await db.doctors.insert_many(docs)
    return {"seeded": [ {"id": str(d["_id"]), "name": d["name"], "specialization": d["specialization"], "available_slots": [s.isoformat() for s in d["available_slots"]]} for d in docs ]}
