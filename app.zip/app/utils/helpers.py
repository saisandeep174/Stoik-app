from fastapi import HTTPException
from datetime import datetime, timezone
from bson import ObjectId

def parse_iso_datetime(s: str) -> datetime:
    try:
        if s.endswith("Z"):
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        else:
            dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        raise HTTPException(status_code=422, detail=f"Invalid datetime format: {s}")

def objid(o: ObjectId) -> str:
    return str(o)
