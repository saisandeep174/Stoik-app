from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import dotenv_values
from passlib.context import CryptContext

from datetime import timedelta
import os
from dotenv import load_dotenv
load_dotenv()


env_config = dotenv_values(".env")


DB_NAME = os.getenv("DB_NAME")
MONGODB_URI = os.getenv("MONGO_URI")
JWT_SECRET = os.getenv("JWT_SECRET")
JWT_ALG = os.getenv("JWT_ALG", "HS256")
JWT_EXPIRE_MIN = int(os.getenv("JWT_EXPIRE_MIN", 60))
ADMIN_KEY = env_config.get("ADMIN_KEY", "changeme")
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID")

# DB
client = AsyncIOMotorClient(MONGODB_URI)
db = client[DB_NAME]

# Password context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


if not JWT_SECRET:
    raise RuntimeError("JWT_SECRET not set")
if not MONGODB_URI:
    raise RuntimeError("MONGODB_URI not set")

