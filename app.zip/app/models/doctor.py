from pydantic import BaseModel, Field
from typing import List

class DoctorCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=80)
    specialization: str = Field(..., min_length=2, max_length=80)
    available_slots: List[str] = Field(default_factory=list)

class DoctorPublic(BaseModel):
    id: str
    name: str
    specialization: str
    available_slots: List[str]
