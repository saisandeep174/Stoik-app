from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import date

class EmergencyContact(BaseModel):
    full_name: str
    relationship: str
    phone: str
    alt_phone: Optional[str] = None

class FamilyMedicalHistory(BaseModel):
    diabetes: bool
    hypertension: bool
    heart_disease: bool
    cancer: Optional[str] = None
    stroke: bool
    mental_health: bool
    genetic_disorders: Optional[str] = None
    other_illnesses: Optional[str] = None

class PersonalMedicalHistory(BaseModel):
    diabetes: bool
    hypertension: bool
    asthma: bool
    heart_disease: bool
    stroke: bool
    cancer: bool
    chronic_kidney_disease: bool
    hepatitis: Optional[str] = None
    hiv_aids: bool
    tuberculosis: bool
    mental_health_issues: bool
    specify_if_yes: Optional[str] = None
    surgeries: Optional[List[str]] = []
    previous_hospitalizations: Optional[List[str]] = []

class Lifestyle(BaseModel):
    smoking_status: str
    alcohol_consumption: str
    exercise: str
    diet_preference: str
    occupation: str

class Medication(BaseModel):
    name: str
    dosage: str
    frequency: str
    reason: str

class MedicationAllergy(BaseModel):
    name: str
    reaction: str

class OtherAllergies(BaseModel):
    food: Optional[str] = None
    food_reaction: Optional[str] = None
    environmental: Optional[str] = None
    environmental_reaction: Optional[str] = None

class UserCreate(BaseModel):
    full_name: str
    date_of_birth: date
    gender: str
    national_id: Optional[str] = None
    phone: str
    email: EmailStr
    address: str
    nationality: str
    marital_status: str
    num_children: int = 0
    primary_caregiver: bool = False
    emergency_contact: EmergencyContact
    family_medical_history: FamilyMedicalHistory
    personal_medical_history: PersonalMedicalHistory
    lifestyle: Lifestyle
    medications: Optional[List[Medication]] = []
    medication_allergies: Optional[List[MedicationAllergy]] = []
    other_allergies: Optional[OtherAllergies] = []
    password: str

class UserPublic(BaseModel):
    id: str
    name: str
    email: EmailStr

class TokenResponse(BaseModel):
    token: str
    user: UserPublic
