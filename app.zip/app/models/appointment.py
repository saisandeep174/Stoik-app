from pydantic import BaseModel

class AppointmentCreate(BaseModel):
    doctor_id: str
    appointment_time: str  

class AppointmentPublic(BaseModel):
    id: str
    user_id: str
    doctor_id: str
    doctor_name: str
    specialization: str
    appointment_time: str
    status: str
